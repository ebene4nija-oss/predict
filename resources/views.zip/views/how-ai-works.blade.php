@extends('layouts.app')

@section('title', 'How AI Football Predictions Work — Expected Goals (xG) Poisson Engine Explained')
@section('meta_description', 'Detailed technical architecture of our deterministic Poisson xG probability engine and how dual AI systems generate synthetic precision football picks.')
@section('meta_keywords', 'how football predictions work, Poisson distribution betting, expected goals xG model, AI football algorithm, sports prediction math, predictive modeling football')
@section('canonical', route('how-ai-works'))

@section('content')
    <div class="max-w-4xl mx-auto space-y-10 py-4">
        <!-- Hero Explainer -->
        <div class="text-center space-y-3">
            <div class="inline-flex items-center space-x-2 px-3.5 py-1.5 rounded-full bg-blue-500/10 border border-blue-500/20 text-[#38BDF8] text-xs font-semibold">
                <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 10V3L4 14h7v7l9-11h-7z"/></svg>
                <span>TRANSPARENT MATHEMATICAL MODELING</span>
            </div>
            <h1 class="text-3xl sm:text-4xl font-black text-white">How Guaranteed Correct Generates Predictions</h1>
            <p class="text-sm text-slate-400 max-w-2xl mx-auto">
                No black-box secrets. Our probabilities come strictly from a deterministic Expected Goals (xG) Poisson statistical engine. The LLM's only job is writing readable tactical previews.
            </p>
        </div>

        <!-- Pipeline Steps Grid -->
        <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div class="p-6 rounded-3xl glass-panel space-y-3 border-l-4 border-l-sky-400">
                <div class="text-xs font-mono font-bold text-sky-400">STEP 1</div>
                <h3 class="text-lg font-bold text-white">Data Ingestion & Team Stats</h3>
                <p class="text-xs leading-relaxed text-slate-300">
                    Nightly background jobs fetch fixtures and recent scoring form &mdash; goals scored and conceded per game for both sides, split home and away. Those figures are the model's entire input.
                </p>
                <p class="text-[11px] leading-relaxed text-slate-400">
                    Head-to-head notes and team news are shown only for fixtures where we hold them; our fixture feed does not supply injury data, so they are added by hand and are often absent. When present they inform the written preview only &mdash; never the probabilities.
                </p>
            </div>

            <div class="p-6 rounded-3xl glass-panel space-y-3 border-l-4 border-l-emerald-400">
                <div class="text-xs font-mono font-bold text-emerald-400">STEP 2</div>
                <h3 class="text-lg font-bold text-white">Poisson Expected Goals (xG) Engine</h3>
                <p class="text-xs leading-relaxed text-slate-300">
                    Expresses each side's attack and defence relative to its league's scoring baseline, giving expected goals for home and away. A Poisson score matrix over 0&ndash;10 goals per side, with the Dixon-Coles correction applied to the low-scoring cells, converts those into win/draw/loss, GG and Over 2.5 probabilities.
                </p>
            </div>

            <div class="p-6 rounded-3xl glass-panel space-y-3 border-l-4 border-l-indigo-400">
                <div class="text-xs font-mono font-bold text-indigo-400">STEP 3</div>
                <h3 class="text-lg font-bold text-white">Gemini LLM Preview Generation</h3>
                <p class="text-xs leading-relaxed text-slate-300">
                    The already-computed probabilities, plus whatever team news we hold, are passed to Gemini to write a two-paragraph tactical preview. The model writes prose only &mdash; it never invents or alters a probability, and where team news is missing it is told so rather than left to guess.
                </p>
            </div>

            <div class="p-6 rounded-3xl glass-panel space-y-3 border-l-4 border-l-amber-400">
                <div class="text-xs font-mono font-bold text-amber-400">STEP 4</div>
                <h3 class="text-lg font-bold text-white">Top 10 & AI Top 5 Ranking</h3>
                <p class="text-xs leading-relaxed text-slate-300">
                    Top 10 lists per market are ranked by confidence. The flagship "AI's Top 5" selects the top 5 highest-conviction cross-market picks across all fixtures.
                </p>
            </div>
        </div>

        <!-- Non-Negotiable Guarantees Card -->
        <div class="p-6 sm:p-8 rounded-3xl bg-[#151A24] border border-sky-500/30 space-y-4">
            <h2 class="text-xl font-bold text-white">Core Architectural Non-Negotiables</h2>
            <ul class="space-y-3 text-xs text-slate-300">
                <li class="flex items-start space-x-3">
                    <span class="text-emerald-400 font-bold">✓</span>
                    <span><strong>Probabilities before Prose:</strong> Numbers are generated by math before any LLM prompt is executed.</span>
                </li>
                <li class="flex items-start space-x-3">
                    <span class="text-emerald-400 font-bold">✓</span>
                    <span><strong>Source Traceability:</strong> AI picks carry an electric blue AI badge (`#38BDF8`). Expert picks carry an amber Expert badge (`#F5A623`) with analyst bio. Sources are never merged into an unlabeled list.</span>
                </li>
                <li class="flex items-start space-x-3">
                    <span class="text-emerald-400 font-bold">✓</span>
                    <span><strong>Ad-Free Subscribers:</strong> Active paid accounts experience zero advertisements across every view.</span>
                </li>
            </ul>
        </div>
    </div>
@endsection
